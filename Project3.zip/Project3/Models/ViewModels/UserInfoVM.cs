﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project3.Models.ViewModels
{
    public class UserInfoVM
    {
		public string Id { get; set; }
		public string Username { get; set; }
    }
}
